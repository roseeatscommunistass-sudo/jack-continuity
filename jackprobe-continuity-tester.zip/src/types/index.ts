export type ContinuityState = 'OPEN' | 'CLOSED' | 'UNKNOWN';

export type TesterMode = 'live' | 'latch' | 'toggle-beep' | 'counter' | 'timer' | 'pair-test';

export interface SignalTelemetry {
  rms: number;             // 0.0 to 1.0 (mic RMS amplitude)
  peak: number;            // 0.0 to 1.0
  dcOffset: number;        // Estimated DC shift / zero-crossing asymmetry (-1.0 to 1.0)
  humIndex: number;        // Mains 50Hz/60Hz spectral ratio
  headsetPlugged: boolean; // Hardware headset plug detected (device routing change)
  inputDeviceName: string; // Active input device
  outputDeviceName: string;// Active output device
  timestamp: number;
}

export interface CalibrationProfile {
  id: string;
  name: string;
  description: string;
  createdAt: number;
  // Baseline thresholds
  openRms: number;
  closedRms: number;
  openDc: number;
  closedDc: number;
  openHum: number;
  closedHum: number;
  // Decision weights
  weightHeadsetPlug: number; // e.g. 0.50
  weightRms: number;         // e.g. 0.25
  weightDc: number;          // e.g. 0.15
  weightHum: number;         // e.g. 0.10
  // Timing
  debounceMs: number;
  minHoldMs: number;
  hysteresisPercent: number; // e.g. 10%
  sensitivityPreset: 'low' | 'normal' | 'high' | 'custom';
}

export interface TestLogEntry {
  id: string;
  timestamp: number;
  state: ContinuityState;
  confidence: number;
  durationMs?: number;
  note?: string;
  mode: TesterMode;
}

export interface PairTestItem {
  id: string;
  label: string; // e.g. "Pin 1 (GND)", "Pin 2 (Data+)", "Wire Red-Blue"
  expected: ContinuityState;
  measured?: ContinuityState;
  confidence?: number;
  passed?: boolean;
  testedAt?: number;
}

export interface DiagnosticsReport {
  timestamp: string;
  userAgent: string;
  audioContextState: string;
  sampleRate: number;
  inputDevices: { label: string; deviceId: string; kind: string }[];
  activeInputDevice: string;
  activeOutputDevice: string;
  currentTelemetry: SignalTelemetry;
  calibrationProfile: CalibrationProfile;
  currentState: ContinuityState;
  confidence: number;
  closureCount: number;
  elapsedClosedMs: number;
}
