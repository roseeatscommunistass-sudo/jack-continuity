/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { MainTesterView } from './components/MainTesterView';

export default function App() {
  return <MainTesterView />;
}
