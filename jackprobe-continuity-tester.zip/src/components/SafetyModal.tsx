import React from 'react';
import { AlertTriangle, ShieldCheck, Zap, Info, X } from 'lucide-react';

interface SafetyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SafetyModal: React.FC<SafetyModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-amber-500/40 rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto shadow-2xl text-slate-100 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-amber-950/30">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-black tracking-wide text-amber-300 uppercase">
                Hardware Safety & Probe Limits
              </h2>
              <p className="text-xs text-slate-400">Essential rules for 3.5mm jack probes</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
            aria-label="Close safety screen"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 text-sm">
          {/* Critical Rule 1 */}
          <div className="p-4 rounded-xl bg-red-950/40 border border-red-500/40 flex items-start gap-3">
            <Zap className="w-6 h-6 text-red-400 shrink-0 mt-0.5" />
            <div>
              <h3 className="font-bold text-red-300 uppercase text-xs tracking-wider">
                Unpowered Circuits Only!
              </h3>
              <p className="text-slate-300 text-xs mt-1 leading-relaxed">
                <strong>NEVER</strong> connect the probe tips to live mains (110V/230V), wall outlets, automotive 12V/24V batteries, power supplies, or charged high-voltage capacitors. Always disconnect all power sources and discharge capacitors before checking continuity.
              </p>
            </div>
          </div>

          {/* Diode Clamp Explanation */}
          <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/80">
            <div className="flex items-center gap-2 mb-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <h4 className="font-bold text-slate-200 text-xs tracking-wider uppercase">
                What the 5.1V Zener Diode Clamp Protects
              </h4>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Your probe has two back-to-back 5.1V glass diodes soldered across the red and black wires. This creates a bidirectional clamp:
            </p>
            <ul className="list-disc list-inside text-xs text-slate-300 mt-2 space-y-1.5">
              <li><strong className="text-emerald-300">Protects against:</strong> Low-energy static electricity (ESD) and slight ground potential differences up to ~5.1V.</li>
              <li><strong className="text-red-400">CANNOT protect against:</strong> Mains voltage or sustained high currents. High energy will vaporize the diodes and instantly destroy your phone's audio codec IC!</li>
            </ul>
          </div>

          {/* Resistor Details */}
          <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/80">
            <div className="flex items-center gap-2 mb-2">
              <Info className="w-5 h-5 text-cyan-400" />
              <h4 className="font-bold text-slate-200 text-xs tracking-wider uppercase">
                Probe Resistor & CTIA Pinout
              </h4>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Your probe uses a resistor (intended <strong>2.2 kΩ</strong>, red-red-red-gold) on Section 3 (Ring 2).
              In modern smartphones (CTIA standard), Section 3 is Ground and Section 4 is Microphone Bias (or vice-versa in OMTP).
              The phone injects a small bias voltage (~2.0V) with an internal ~2.2kΩ pull-up. Touching the probes closes this circuit, triggering headset detection and shifting audio impedance!
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/90 flex justify-end">
          <button
            onClick={onClose}
            className="w-full py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm tracking-wide transition shadow-lg shadow-amber-500/20"
          >
            I UNDERSTAND — PROCEED SAFELY
          </button>
        </div>
      </div>
    </div>
  );
};
