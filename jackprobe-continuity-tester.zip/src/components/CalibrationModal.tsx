import React, { useState, useEffect } from 'react';
import { Sliders, CheckCircle2, AlertCircle, ArrowRight, RotateCcw, Save, Download, Upload, X } from 'lucide-react';
import { CalibrationProfile, SignalTelemetry } from '../types';
import { DEFAULT_CALIBRATION_PROFILE } from '../services/fusionEngine';

interface CalibrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  telemetry: SignalTelemetry;
  activeProfile: CalibrationProfile;
  onSaveProfile: (profile: CalibrationProfile) => void;
}

export const CalibrationModal: React.FC<CalibrationModalProps> = ({
  isOpen,
  onClose,
  telemetry,
  activeProfile,
  onSaveProfile
}) => {
  const [profile, setProfile] = useState<CalibrationProfile>({ ...activeProfile });
  const [activeTab, setActiveTab] = useState<'wizard' | 'manual' | 'profiles'>('wizard');
  const [wizardStep, setWizardStep] = useState<1 | 2 | 3>(1);
  const [isSampling, setIsSampling] = useState<boolean>(false);
  const [sampleProgress, setSampleProgress] = useState<number>(0);

  // Temporary sample accumulator
  const [samplesRms, setSamplesRms] = useState<number[]>([]);
  const [samplesDc, setSamplesDc] = useState<number[]>([]);
  const [samplesHum, setSamplesHum] = useState<number[]>([]);

  useEffect(() => {
    if (isOpen) {
      setProfile({ ...activeProfile });
      setWizardStep(1);
      setIsSampling(false);
      setSampleProgress(0);
    }
  }, [isOpen, activeProfile]);

  // Sampling accumulation loop
  useEffect(() => {
    if (!isSampling) return;

    setSamplesRms(prev => [...prev, telemetry.rms]);
    setSamplesDc(prev => [...prev, telemetry.dcOffset]);
    setSamplesHum(prev => [...prev, telemetry.humIndex]);

    const timer = setInterval(() => {
      setSampleProgress(p => {
        if (p >= 100) {
          clearInterval(timer);
          setIsSampling(false);
          return 100;
        }
        return p + 5;
      });
    }, 100);

    return () => clearInterval(timer);
  }, [isSampling, telemetry]);

  if (!isOpen) return null;

  const startSampling = () => {
    setSamplesRms([]);
    setSamplesDc([]);
    setSamplesHum([]);
    setSampleProgress(0);
    setIsSampling(true);
  };

  const finishStep1 = () => {
    if (samplesRms.length === 0) return;
    const avgRms = samplesRms.reduce((a, b) => a + b, 0) / samplesRms.length;
    const avgDc = samplesDc.reduce((a, b) => a + b, 0) / samplesDc.length;
    const avgHum = samplesHum.reduce((a, b) => a + b, 0) / samplesHum.length;

    setProfile(p => ({
      ...p,
      openRms: avgRms,
      openDc: avgDc,
      openHum: avgHum
    }));

    setWizardStep(2);
    setSampleProgress(0);
    setIsSampling(false);
  };

  const finishStep2 = () => {
    if (samplesRms.length === 0) return;
    const avgRms = samplesRms.reduce((a, b) => a + b, 0) / samplesRms.length;
    const avgDc = samplesDc.reduce((a, b) => a + b, 0) / samplesDc.length;
    const avgHum = samplesHum.reduce((a, b) => a + b, 0) / samplesHum.length;

    // Calculate separabilities
    const rmsDiff = Math.abs(profile.openRms - avgRms);
    const dcDiff = Math.abs(profile.openDc - avgDc);
    const humDiff = Math.abs(profile.openHum - avgHum);

    // Dynamic weight allocation based on which signal separates clearest
    const totalDiff = rmsDiff + dcDiff + humDiff;
    let wRms = 0.25;
    let wDc = 0.15;
    let wHum = 0.15;
    if (totalDiff > 0.05) {
      wRms = Math.max(0.1, (rmsDiff / totalDiff) * 0.5);
      wDc = Math.max(0.1, (dcDiff / totalDiff) * 0.5);
      wHum = Math.max(0.1, (humDiff / totalDiff) * 0.5);
    }

    setProfile(p => ({
      ...p,
      closedRms: avgRms,
      closedDc: avgDc,
      closedHum: avgHum,
      weightHeadsetPlug: 0.50,
      weightRms: Number(wRms.toFixed(2)),
      weightDc: Number(wDc.toFixed(2)),
      weightHum: Number(wHum.toFixed(2))
    }));

    setWizardStep(3);
    setSampleProgress(0);
    setIsSampling(false);
  };

  // Separability analysis
  const rmsDelta = Math.abs(profile.openRms - profile.closedRms);
  const dcDelta = Math.abs(profile.openDc - profile.closedDc);
  const humDelta = Math.abs(profile.openHum - profile.closedHum);
  
  // Total separability score (0 to 100%)
  const separabilityScore = Math.min(100, Math.round((rmsDelta * 120) + (dcDelta * 180) + (humDelta * 80)));
  
  const separabilityVerdict = separabilityScore > 75 
    ? { title: 'EXCELLENT SEPARABILITY', text: 'Signals differ clearly. Continuity detection will be extremely accurate and fast.', color: 'text-emerald-400', bg: 'bg-emerald-950/40 border-emerald-500/40' }
    : separabilityScore > 45
    ? { title: 'GOOD SEPARABILITY', text: 'Moderate signal difference. Headset detection and RMS will reliably detect contact.', color: 'text-cyan-400', bg: 'bg-cyan-950/40 border-cyan-500/40' }
    : { title: 'WEAK / INDISTINGUISHABLE', text: 'Small difference between open and closed. Check that the 2.2kΩ resistor is properly soldered to Pin 3 & 4.', color: 'text-amber-400', bg: 'bg-amber-950/40 border-amber-500/40' };

  const handleSaveAndApply = () => {
    onSaveProfile(profile);
    onClose();
  };

  const handleExportProfile = () => {
    const json = JSON.stringify(profile, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `VoltJack-Calibration-${profile.name.replace(/\s+/g, '-')}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportProfile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const parsed = JSON.parse(evt.target?.result as string);
        if (parsed.openRms !== undefined && parsed.closedRms !== undefined) {
          setProfile(parsed);
        }
      } catch {
        alert('Invalid calibration JSON file format.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-xl w-full max-h-[92vh] overflow-y-auto shadow-2xl text-slate-100 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-500/20 text-blue-400">
              <Sliders className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-black tracking-wide text-blue-300 uppercase">
                Probe Calibration & Tuning
              </h2>
              <p className="text-xs text-slate-400">Match phone audio thresholds to your probe resistor</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-900 px-4">
          <button
            onClick={() => setActiveTab('wizard')}
            className={`py-3 px-4 text-xs font-bold uppercase tracking-wider border-b-2 transition ${
              activeTab === 'wizard' ? 'border-blue-500 text-blue-400' : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Guided 3-Step Wizard
          </button>
          <button
            onClick={() => setActiveTab('manual')}
            className={`py-3 px-4 text-xs font-bold uppercase tracking-wider border-b-2 transition ${
              activeTab === 'manual' ? 'border-blue-500 text-blue-400' : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Manual Thresholds & Timing
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-6 space-y-6 flex-1 text-sm">
          {activeTab === 'wizard' && (
            <div className="space-y-5">
              {/* Step indicator */}
              <div className="flex items-center justify-between gap-2 px-2 text-xs font-bold uppercase">
                <span className={wizardStep === 1 ? 'text-blue-400' : 'text-slate-500'}>1. Probes Apart</span>
                <ArrowRight className="w-3.5 h-3.5 text-slate-600" />
                <span className={wizardStep === 2 ? 'text-blue-400' : 'text-slate-500'}>2. Probes Touching</span>
                <ArrowRight className="w-3.5 h-3.5 text-slate-600" />
                <span className={wizardStep === 3 ? 'text-blue-400' : 'text-slate-500'}>3. Results</span>
              </div>

              {wizardStep === 1 && (
                <div className="p-5 rounded-xl bg-slate-800/60 border border-slate-700/80 space-y-4">
                  <div>
                    <h3 className="font-bold text-slate-100 uppercase tracking-wide">
                      Step 1: Keep Probes Apart (Open Circuit)
                    </h3>
                    <p className="text-xs text-slate-400 mt-1">
                      Hold the red and black probe tips separated in mid-air. Do not let them touch any metal. We will record the open antenna noise baseline.
                    </p>
                  </div>

                  <div className="p-3 bg-slate-900 rounded-lg text-xs font-mono flex items-center justify-between">
                    <span className="text-slate-400">Live Mic RMS:</span>
                    <span className="text-cyan-400 font-bold">{(telemetry.rms * 100).toFixed(1)}%</span>
                  </div>

                  {isSampling ? (
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs text-slate-400 font-mono">
                        <span>Recording Open Baseline...</span>
                        <span>{sampleProgress}%</span>
                      </div>
                      <div className="w-full bg-slate-700 h-2.5 rounded-full overflow-hidden">
                        <div className="bg-blue-500 h-full transition-all duration-100" style={{ width: `${sampleProgress}%` }} />
                      </div>
                      {sampleProgress >= 100 && (
                        <button
                          onClick={finishStep1}
                          className="w-full mt-3 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase"
                        >
                          Confirm Open Baseline → Proceed to Step 2
                        </button>
                      )}
                    </div>
                  ) : (
                    <button
                      onClick={startSampling}
                      className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-wider"
                    >
                      Start 2-Second Open Calibration
                    </button>
                  )}
                </div>
              )}

              {wizardStep === 2 && (
                <div className="p-5 rounded-xl bg-slate-800/60 border border-slate-700/80 space-y-4">
                  <div>
                    <h3 className="font-bold text-slate-100 uppercase tracking-wide">
                      Step 2: Touch Probe Tips Together (Closed Circuit)
                    </h3>
                    <p className="text-xs text-slate-400 mt-1">
                      Firmly press the red and black probe tips together and hold them closed. We will record the 2.2kΩ ground pull baseline.
                    </p>
                  </div>

                  <div className="p-3 bg-slate-900 rounded-lg text-xs font-mono flex items-center justify-between">
                    <span className="text-slate-400">Live Mic RMS:</span>
                    <span className="text-emerald-400 font-bold">{(telemetry.rms * 100).toFixed(1)}%</span>
                  </div>

                  {isSampling ? (
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs text-slate-400 font-mono">
                        <span>Recording Closed Baseline...</span>
                        <span>{sampleProgress}%</span>
                      </div>
                      <div className="w-full bg-slate-700 h-2.5 rounded-full overflow-hidden">
                        <div className="bg-emerald-500 h-full transition-all duration-100" style={{ width: `${sampleProgress}%` }} />
                      </div>
                      {sampleProgress >= 100 && (
                        <button
                          onClick={finishStep2}
                          className="w-full mt-3 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase"
                        >
                          Calculate Separability & Results →
                        </button>
                      )}
                    </div>
                  ) : (
                    <button
                      onClick={startSampling}
                      className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider"
                    >
                      Start 2-Second Closed Calibration
                    </button>
                  )}
                </div>
              )}

              {wizardStep === 3 && (
                <div className="space-y-4">
                  <div className={`p-4 rounded-xl border ${separabilityVerdict.bg}`}>
                    <div className="flex items-center justify-between">
                      <h4 className={`font-black text-sm uppercase ${separabilityVerdict.color}`}>
                        {separabilityVerdict.title} ({separabilityScore}%)
                      </h4>
                      <CheckCircle2 className={`w-5 h-5 ${separabilityVerdict.color}`} />
                    </div>
                    <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                      {separabilityVerdict.text}
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                    <div className="p-3 bg-slate-800 rounded-lg">
                      <span className="text-slate-400 block text-[10px] uppercase font-bold">Open Baseline</span>
                      <p className="text-slate-200 mt-1">RMS: {(profile.openRms * 100).toFixed(1)}%</p>
                      <p className="text-slate-400">DC: {profile.openDc.toFixed(3)}</p>
                    </div>
                    <div className="p-3 bg-slate-800 rounded-lg">
                      <span className="text-slate-400 block text-[10px] uppercase font-bold">Closed Baseline</span>
                      <p className="text-emerald-400 mt-1">RMS: {(profile.closedRms * 100).toFixed(1)}%</p>
                      <p className="text-slate-400">DC: {profile.closedDc.toFixed(3)}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => setWizardStep(1)}
                    className="w-full py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium"
                  >
                    Run Wizard Again
                  </button>
                </div>
              )}
            </div>
          )}

          {activeTab === 'manual' && (
            <div className="space-y-4 text-xs">
              <div className="p-3 bg-slate-800/80 rounded-xl space-y-3">
                <h4 className="font-bold text-slate-200 uppercase tracking-wider">Detection Timing & Debounce</h4>
                <div>
                  <div className="flex justify-between text-slate-400 mb-1">
                    <span>Debounce: {profile.debounceMs} ms</span>
                    <span>(Rejects contact chatter)</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="150"
                    value={profile.debounceMs}
                    onChange={e => setProfile({ ...profile, debounceMs: Number(e.target.value) })}
                    className="w-full accent-blue-500"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-slate-400 mb-1">
                    <span>Min Hold Duration: {profile.minHoldMs} ms</span>
                    <span>(Locks short closures)</span>
                  </div>
                  <input
                    type="range"
                    min="20"
                    max="300"
                    value={profile.minHoldMs}
                    onChange={e => setProfile({ ...profile, minHoldMs: Number(e.target.value) })}
                    className="w-full accent-blue-500"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-slate-400 mb-1">
                    <span>Hysteresis Band: ±{profile.hysteresisPercent}%</span>
                    <span>(Prevents boundary flutter)</span>
                  </div>
                  <input
                    type="range"
                    min="4"
                    max="30"
                    value={profile.hysteresisPercent}
                    onChange={e => setProfile({ ...profile, hysteresisPercent: Number(e.target.value) })}
                    className="w-full accent-blue-500"
                  />
                </div>
              </div>

              <div className="p-3 bg-slate-800/80 rounded-xl space-y-3">
                <h4 className="font-bold text-slate-200 uppercase tracking-wider">Signal Weights</h4>
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <label className="text-slate-400 block mb-0.5">Headset Plug: {(profile.weightHeadsetPlug * 100).toFixed(0)}%</label>
                    <input
                      type="range"
                      min="0.1"
                      max="0.8"
                      step="0.05"
                      value={profile.weightHeadsetPlug}
                      onChange={e => setProfile({ ...profile, weightHeadsetPlug: parseFloat(e.target.value) })}
                      className="w-full accent-blue-500"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-0.5">Mic RMS: {(profile.weightRms * 100).toFixed(0)}%</label>
                    <input
                      type="range"
                      min="0.1"
                      max="0.8"
                      step="0.05"
                      value={profile.weightRms}
                      onChange={e => setProfile({ ...profile, weightRms: parseFloat(e.target.value) })}
                      className="w-full accent-blue-500"
                    />
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  onClick={() => setProfile({ ...DEFAULT_CALIBRATION_PROFILE })}
                  className="py-2 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" /> Reset Defaults
                </button>
                <button
                  onClick={handleExportProfile}
                  className="py-2 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" /> Export JSON
                </button>
                <label className="py-2 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium flex items-center gap-1.5 cursor-pointer">
                  <Upload className="w-3.5 h-3.5" /> Import JSON
                  <input type="file" accept=".json" onChange={handleImportProfile} className="hidden" />
                </label>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950 flex justify-end gap-3">
          <button
            onClick={onClose}
            className="py-2.5 px-4 rounded-xl text-slate-400 hover:text-white font-medium text-xs uppercase"
          >
            Cancel
          </button>
          <button
            onClick={handleSaveAndApply}
            className="py-2.5 px-5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-blue-600/20"
          >
            <Save className="w-4 h-4" /> Save & Apply Calibration
          </button>
        </div>
      </div>
    </div>
  );
};
