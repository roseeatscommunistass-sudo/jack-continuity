import React, { useState } from 'react';
import { Layers, CheckCircle, XCircle, Plus, RotateCcw, X } from 'lucide-react';
import { PairTestItem, ContinuityState } from '../types';
import { soundEffects } from '../services/soundEffects';
import { haptics } from '../services/haptics';

interface PairTestModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentState: ContinuityState;
  confidence: number;
}

const DEFAULT_PAIRS: PairTestItem[] = [
  { id: '1', label: 'Wire Pair 1: Ground (GND)', expected: 'CLOSED' },
  { id: '2', label: 'Wire Pair 2: Signal A / Data+', expected: 'CLOSED' },
  { id: '3', label: 'Wire Pair 3: Signal B / Data-', expected: 'CLOSED' },
  { id: '4', label: 'Wire Pair 4: Shield / Chassis', expected: 'CLOSED' },
];

export const PairTestModal: React.FC<PairTestModalProps> = ({
  isOpen,
  onClose,
  currentState,
  confidence
}) => {
  const [items, setItems] = useState<PairTestItem[]>(DEFAULT_PAIRS);
  const [activeIndex, setActiveIndex] = useState<number>(0);
  const [newLabel, setNewLabel] = useState<string>('');

  if (!isOpen) return null;

  const currentItem = items[activeIndex];

  const handleRecordActive = () => {
    if (!currentItem) return;
    const passed = currentState === currentItem.expected;
    const updated = [...items];
    updated[activeIndex] = {
      ...currentItem,
      measured: currentState,
      confidence,
      passed,
      testedAt: Date.now()
    };
    setItems(updated);

    if (passed) {
      soundEffects.playShortChirp('pass');
      haptics.triggerPass();
    } else {
      soundEffects.playShortChirp('fail');
      haptics.triggerFail();
    }

    // Advance to next unverified item
    if (activeIndex < items.length - 1) {
      setActiveIndex(activeIndex + 1);
    }
  };

  const handleReset = () => {
    setItems(items.map(item => ({
      ...item,
      measured: undefined,
      confidence: undefined,
      passed: undefined,
      testedAt: undefined
    })));
    setActiveIndex(0);
  };

  const handleAddItem = () => {
    if (!newLabel.trim()) return;
    const newItem: PairTestItem = {
      id: Date.now().toString(),
      label: newLabel.trim(),
      expected: 'CLOSED'
    };
    setItems([...items, newItem]);
    setNewLabel('');
  };

  const passedCount = items.filter(i => i.passed === true).length;
  const failedCount = items.filter(i => i.passed === false).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto shadow-2xl text-slate-100 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-500/20 text-indigo-400">
              <Layers className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-black tracking-wide text-indigo-300 uppercase">
                Pair & Multi-Pin Sequencer
              </h2>
              <p className="text-xs text-slate-400">Sequential cable harness continuity verification</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Target Banner */}
        {currentItem && (
          <div className="p-4 bg-indigo-950/40 border-b border-indigo-900/50 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-bold uppercase text-indigo-400">
                Target Pin ({activeIndex + 1} of {items.length})
              </span>
              <h3 className="font-bold text-slate-100 text-sm">{currentItem.label}</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Probe live reading: <strong className={currentState === 'CLOSED' ? 'text-emerald-400' : 'text-red-400'}>{currentState}</strong> ({confidence}%)
              </p>
            </div>
            <button
              onClick={handleRecordActive}
              className="py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-indigo-600/30"
            >
              Verify Now
            </button>
          </div>
        )}

        {/* Items List */}
        <div className="p-5 space-y-2 flex-1 overflow-y-auto text-xs">
          {items.map((item, idx) => (
            <div
              key={item.id}
              onClick={() => setActiveIndex(idx)}
              className={`p-3 rounded-xl border cursor-pointer transition flex items-center justify-between ${
                idx === activeIndex
                  ? 'bg-slate-800 border-indigo-500 ring-1 ring-indigo-500/50'
                  : 'bg-slate-800/40 border-slate-700/60 hover:bg-slate-800/70'
              }`}
            >
              <div className="flex items-center gap-3">
                <span className="w-5 h-5 rounded-full bg-slate-700 text-slate-300 flex items-center justify-center text-[10px] font-bold">
                  {idx + 1}
                </span>
                <span className="font-semibold text-slate-200">{item.label}</span>
              </div>

              <div className="flex items-center gap-2">
                {item.passed === true && (
                  <span className="flex items-center gap-1 text-emerald-400 font-bold">
                    <CheckCircle className="w-4 h-4" /> PASS
                  </span>
                )}
                {item.passed === false && (
                  <span className="flex items-center gap-1 text-red-400 font-bold">
                    <XCircle className="w-4 h-4" /> FAIL
                  </span>
                )}
                {item.passed === undefined && (
                  <span className="text-slate-500 font-mono text-[11px]">PENDING</span>
                )}
              </div>
            </div>
          ))}

          {/* Add custom pin */}
          <div className="flex items-center gap-2 pt-2">
            <input
              type="text"
              placeholder="Add pin label (e.g. Pin 5 - VCC)..."
              value={newLabel}
              onChange={e => setNewLabel(e.target.value)}
              className="flex-1 bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 text-xs placeholder:text-slate-500"
            />
            <button
              onClick={handleAddItem}
              className="py-2 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" /> Add
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950 flex items-center justify-between text-xs">
          <div className="flex items-center gap-3">
            <span className="text-emerald-400 font-bold">{passedCount} Passed</span>
            <span className="text-red-400 font-bold">{failedCount} Failed</span>
          </div>
          <button
            onClick={handleReset}
            className="py-2 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium flex items-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Reset All
          </button>
        </div>
      </div>
    </div>
  );
};
