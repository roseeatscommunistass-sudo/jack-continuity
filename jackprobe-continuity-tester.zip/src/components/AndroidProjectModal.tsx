import React, { useState } from 'react';
import { Smartphone, Download, Copy, Check, FileCode, ExternalLink, HelpCircle, X, Terminal } from 'lucide-react';
import JSZip from 'jszip';
import { ANDROID_PROJECT_FILES } from '../data/defaultAndroidProject';

interface AndroidProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidProjectModal: React.FC<AndroidProjectModalProps> = ({ isOpen, onClose }) => {
  const [selectedFileIndex, setSelectedFileIndex] = useState<number>(0);
  const [copiedFile, setCopiedFile] = useState<boolean>(false);
  const [isZipping, setIsZipping] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'cloud-apk' | 'files'>('cloud-apk');

  if (!isOpen) return null;

  const currentFile = ANDROID_PROJECT_FILES[selectedFileIndex] || ANDROID_PROJECT_FILES[0];

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      const zip = new JSZip();

      // Add all project files
      ANDROID_PROJECT_FILES.forEach(file => {
        zip.file(file.path, file.content);
      });

      // Add gradlew shell script and bat file
      zip.file('gradlew', `#!/usr/bin/env sh
# Minimal POSIX Gradle wrapper fallback
exec gradle "$@"
`);
      zip.file('gradlew.bat', `@rem Minimal Windows Gradle wrapper fallback
@gradle %*
`);

      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'VoltJack-Native-Android-Project.zip';
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to generate zip:', err);
      alert('Could not generate ZIP file.');
    } finally {
      setIsZipping(false);
    }
  };

  const handleCopyCurrentFile = () => {
    navigator.clipboard.writeText(currentFile.content);
    setCopiedFile(true);
    setTimeout(() => setCopiedFile(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="bg-slate-900 border border-emerald-500/30 rounded-2xl max-w-4xl w-full max-h-[92vh] overflow-hidden shadow-2xl text-slate-100 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400">
              <Smartphone className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black tracking-wide text-emerald-400 uppercase">
                Native Android Companion (APK & Source)
              </h2>
              <p className="text-xs text-slate-400">
                Kotlin • Jetpack Compose • Material 3 • Cloud APK Build
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Top Bar */}
        <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('cloud-apk')}
              className={`py-2 px-3.5 rounded-lg text-xs font-bold uppercase tracking-wider transition ${
                activeTab === 'cloud-apk'
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              1. Build APK on Phone (No Computer)
            </button>
            <button
              onClick={() => setActiveTab('files')}
              className={`py-2 px-3.5 rounded-lg text-xs font-bold uppercase tracking-wider transition ${
                activeTab === 'files'
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              2. Inspect & Copy Source Code
            </button>
          </div>

          <button
            onClick={handleDownloadZip}
            disabled={isZipping}
            className="py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center gap-2 transition shadow-lg shadow-emerald-500/20 disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            {isZipping ? 'Packaging ZIP...' : 'Download Full Android Project (.ZIP)'}
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto">
          {activeTab === 'cloud-apk' ? (
            <div className="p-5 sm:p-6 space-y-6 text-sm">
              <div className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-500/30">
                <h3 className="font-black text-emerald-300 uppercase tracking-wide flex items-center gap-2">
                  <Terminal className="w-4 h-4" /> How to get the APK file using only your phone
                </h3>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  You don't need Android Studio or a computer! The project includes a GitHub Actions workflow that compiles the APK automatically in the cloud.
                </p>
              </div>

              {/* Step by step */}
              <div className="space-y-4">
                <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-emerald-500 text-slate-950 font-black text-xs flex items-center justify-center">1</span>
                    <h4 className="font-bold text-slate-100 text-xs uppercase tracking-wide">Download the Project ZIP</h4>
                  </div>
                  <p className="text-xs text-slate-400 pl-8">
                    Tap the green <strong>"Download Full Android Project (.ZIP)"</strong> button above. This saves all Kotlin files, Gradle configs, and the GitHub build script directly to your phone's downloads folder.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-emerald-500 text-slate-950 font-black text-xs flex items-center justify-center">2</span>
                    <h4 className="font-bold text-slate-100 text-xs uppercase tracking-wide">Create a Repository on GitHub</h4>
                  </div>
                  <p className="text-xs text-slate-400 pl-8 leading-relaxed">
                    Open Chrome on your phone, go to <strong>github.com</strong>, tap <strong>"+"</strong> → <strong>New repository</strong>. Name it <code className="text-emerald-400 bg-slate-900 px-1 rounded">voltjack-tester</code>. Choose <strong>Public</strong>, then tap <strong>Create repository</strong>.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-emerald-500 text-slate-950 font-black text-xs flex items-center justify-center">3</span>
                    <h4 className="font-bold text-slate-100 text-xs uppercase tracking-wide">Upload the Files</h4>
                  </div>
                  <p className="text-xs text-slate-400 pl-8 leading-relaxed">
                    On your new repository page, tap <strong>"uploading an existing file"</strong>. Extract your downloaded ZIP and select the files, or upload the workflow file <code className="text-cyan-400 bg-slate-900 px-1 rounded">.github/workflows/build.yml</code> and commit changes.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-emerald-500 text-slate-950 font-black text-xs flex items-center justify-center">4</span>
                    <h4 className="font-bold text-slate-100 text-xs uppercase tracking-wide">Run Workflow & Download the .APK</h4>
                  </div>
                  <p className="text-xs text-slate-400 pl-8 leading-relaxed">
                    Tap the <strong>Actions</strong> tab on your repo. You will see <strong>"Build VoltJack Debug APK"</strong>. Tap <strong>Run workflow</strong>. In ~2 minutes, the cloud build completes with a green checkmark! Tap the run, scroll down to <strong>Artifacts</strong>, and tap <strong>VoltJack-Debug-APK</strong> to download and install!
                  </p>
                </div>
              </div>

              {/* Direct Web App Alternative Note */}
              <div className="p-4 rounded-xl bg-blue-950/30 border border-blue-500/30 text-xs text-slate-300">
                <span className="font-bold text-blue-300 uppercase block mb-1">
                  💡 Pro-Tip: You Can Also Test Right Now In This Web App!
                </span>
                The Web Audio analyzer running in this app uses the exact same signal thresholds, microphone RMS, and headset switch detection as the native app. You can plug your 3.5mm probe in right now to verify continuity!
              </div>
            </div>
          ) : (
            <div className="flex flex-col md:flex-row h-full min-h-[450px]">
              {/* File list sidebar */}
              <div className="w-full md:w-72 border-r border-slate-800 bg-slate-950/60 p-3 space-y-1 overflow-y-auto max-h-56 md:max-h-none">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 px-2 block mb-2">
                  Source Files ({ANDROID_PROJECT_FILES.length})
                </span>
                {ANDROID_PROJECT_FILES.map((f, i) => (
                  <button
                    key={f.path}
                    onClick={() => setSelectedFileIndex(i)}
                    className={`w-full text-left p-2 rounded-lg text-xs font-mono transition truncate block ${
                      i === selectedFileIndex
                        ? 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 font-bold'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                    }`}
                  >
                    {f.path}
                  </button>
                ))}
              </div>

              {/* Code viewer */}
              <div className="flex-1 flex flex-col bg-slate-950 overflow-hidden">
                <div className="p-3 border-b border-slate-800 bg-slate-900/60 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-mono text-emerald-400 font-bold">{currentFile.path}</span>
                    <p className="text-[11px] text-slate-400 mt-0.5">{currentFile.description}</p>
                  </div>
                  <button
                    onClick={handleCopyCurrentFile}
                    className="py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center gap-1.5 transition"
                  >
                    {copiedFile ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    {copiedFile ? 'Copied!' : 'Copy Code'}
                  </button>
                </div>
                <pre className="flex-1 p-4 overflow-auto text-xs font-mono text-slate-300 leading-relaxed select-all whitespace-pre">
                  {currentFile.content}
                </pre>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
