import React, { useState } from 'react';
import { History, Download, Trash2, Filter, Search, X } from 'lucide-react';
import { TestLogEntry } from '../types';

interface LogViewModalProps {
  isOpen: boolean;
  onClose: () => void;
  logs: TestLogEntry[];
  onClearLogs: () => void;
}

export const LogViewModal: React.FC<LogViewModalProps> = ({
  isOpen,
  onClose,
  logs,
  onClearLogs
}) => {
  const [filter, setFilter] = useState<'ALL' | 'CLOSED' | 'OPEN'>('ALL');
  const [search, setSearch] = useState('');

  if (!isOpen) return null;

  const filteredLogs = logs.filter(log => {
    if (filter !== 'ALL' && log.state !== filter) return false;
    if (search && !log.id.includes(search) && !(log.note || '').toLowerCase().includes(search.toLowerCase())) {
      return false;
    }
    return true;
  });

  const exportCSV = () => {
    const headers = ['Timestamp', 'ISO Time', 'State', 'Confidence (%)', 'Duration (ms)', 'Mode', 'Note'];
    const rows = logs.map(l => [
      l.timestamp,
      new Date(l.timestamp).toISOString(),
      l.state,
      l.confidence,
      l.durationMs || 0,
      l.mode,
      `"${l.note || ''}"`
    ]);
    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `VoltJack-Logs-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportJSON = () => {
    const json = JSON.stringify(logs, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `VoltJack-Logs-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden shadow-2xl text-slate-100 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-purple-500/20 text-purple-400">
              <History className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-black tracking-wide text-purple-300 uppercase">
                Continuity Test Logs ({logs.length})
              </h2>
              <p className="text-xs text-slate-400">Timestamped record of all probe transitions</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toolbar */}
        <div className="p-4 border-b border-slate-800 bg-slate-900/60 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-slate-400 font-bold uppercase flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" /> Filter:
            </span>
            {(['ALL', 'CLOSED', 'OPEN'] as const).map(f => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`py-1.5 px-3 rounded-lg font-bold transition ${
                  filter === f
                    ? 'bg-purple-600 text-white'
                    : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {f}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={exportCSV}
              className="py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" /> CSV
            </button>
            <button
              onClick={exportJSON}
              className="py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" /> JSON
            </button>
            <button
              onClick={onClearLogs}
              className="py-1.5 px-3 rounded-lg bg-red-950/60 hover:bg-red-900 border border-red-800/60 text-red-300 font-bold flex items-center gap-1.5"
            >
              <Trash2 className="w-3.5 h-3.5 text-red-400" /> Clear
            </button>
          </div>
        </div>

        {/* List Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {filteredLogs.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-sm">
              No continuity log entries found. Test probe closures to record events!
            </div>
          ) : (
            filteredLogs.slice().reverse().map(entry => (
              <div
                key={entry.id}
                className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`font-black uppercase px-2 py-0.5 rounded text-[11px] ${
                      entry.state === 'CLOSED'
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                        : 'bg-red-500/20 text-red-400 border border-red-500/40'
                    }`}
                  >
                    {entry.state}
                  </span>
                  <div>
                    <span className="font-mono text-slate-300 font-semibold">
                      {new Date(entry.timestamp).toLocaleTimeString()}
                    </span>
                    <span className="text-slate-500 ml-2 font-mono">
                      (Conf: {entry.confidence}%)
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-slate-400 font-mono">
                  {entry.durationMs ? (
                    <span className="text-slate-300">
                      Duration: <strong>{(entry.durationMs / 1000).toFixed(2)}s</strong>
                    </span>
                  ) : null}
                  <span className="uppercase text-[10px] text-slate-500 bg-slate-900 px-2 py-0.5 rounded">
                    {entry.mode}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
