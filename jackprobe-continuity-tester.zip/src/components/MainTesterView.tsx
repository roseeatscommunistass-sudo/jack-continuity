import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Volume2,
  VolumeX,
  Vibrate,
  Flashlight,
  Sparkles,
  Play,
  Pause,
  RotateCcw,
  Sliders,
  Activity,
  History,
  Layers,
  Shield,
  Smartphone,
  Headphones,
  CheckCircle,
  AlertTriangle,
  HelpCircle,
  Zap,
  Mic,
  MicOff,
  Flame
} from 'lucide-react';
import { ContinuityState, TesterMode, SignalTelemetry, CalibrationProfile, TestLogEntry } from '../types';
import { audioEngine } from '../services/audioEngine';
import { FusionEngine, DEFAULT_CALIBRATION_PROFILE } from '../services/fusionEngine';
import { soundEffects } from '../services/soundEffects';
import { haptics } from '../services/haptics';
import { ttsService } from '../services/tts';
import { CalibrationModal } from './CalibrationModal';
import { DiagnosticsModal } from './DiagnosticsModal';
import { LogViewModal } from './LogViewModal';
import { PairTestModal } from './PairTestModal';
import { SafetyModal } from './SafetyModal';
import { AndroidProjectModal } from './AndroidProjectModal';

export const MainTesterView: React.FC = () => {
  // State
  const [telemetry, setTelemetry] = useState<SignalTelemetry>({
    rms: 0,
    peak: 0,
    dcOffset: 0,
    humIndex: 0,
    headsetPlugged: false,
    inputDeviceName: 'Checking...',
    outputDeviceName: 'Speaker Out',
    timestamp: Date.now()
  });

  const [activeProfile, setActiveProfile] = useState<CalibrationProfile>(DEFAULT_CALIBRATION_PROFILE);
  const fusionEngineRef = useRef<FusionEngine>(new FusionEngine(DEFAULT_CALIBRATION_PROFILE));

  const [currentState, setCurrentState] = useState<ContinuityState>('UNKNOWN');
  const [confidence, setConfidence] = useState<number>(0);
  const [mode, setMode] = useState<TesterMode>('live');

  // Feedback Toggles
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [vibeEnabled, setVibeEnabled] = useState<boolean>(true);
  const [screenFlashEnabled, setScreenFlashEnabled] = useState<boolean>(true);
  const [ttsEnabled, setTtsEnabled] = useState<boolean>(false);
  const [torchEnabled, setTorchEnabled] = useState<boolean>(false);

  // App Controls
  const [isFrozen, setIsFrozen] = useState<boolean>(false);
  const [isAudioRunning, setIsAudioRunning] = useState<boolean>(false);
  const [isSimulated, setIsSimulated] = useState<boolean>(false);
  const [simulatedClosed, setSimulatedClosed] = useState<boolean>(false);

  // Metrics & Stats
  const [closureCount, setClosureCount] = useState<number>(0);
  const [totalClosedMs, setTotalClosedMs] = useState<number>(0);
  const [logs, setLogs] = useState<TestLogEntry[]>([]);

  // Latch mode memory
  const [latchedClosed, setLatchedClosed] = useState<boolean>(false);

  // Screen Flash animation state
  const [screenFlashActive, setScreenFlashActive] = useState<boolean>(false);

  // Modals
  const [isCalibrationOpen, setIsCalibrationOpen] = useState<boolean>(false);
  const [isDiagnosticsOpen, setIsDiagnosticsOpen] = useState<boolean>(false);
  const [isLogsOpen, setIsLogsOpen] = useState<boolean>(false);
  const [isPairTestOpen, setIsPairTestOpen] = useState<boolean>(false);
  const [isSafetyOpen, setIsSafetyOpen] = useState<boolean>(false);
  const [isAndroidModalOpen, setIsAndroidModalOpen] = useState<boolean>(false);

  // Contact duration tracking
  const contactStartRef = useRef<number | null>(null);

  // Auto start audio engine on mount
  useEffect(() => {
    const startMic = async () => {
      const ok = await audioEngine.startAudio(false);
      setIsAudioRunning(ok);
      if (!ok) {
        // Fallback to simulation mode if mic blocked or in restrictive iframe
        audioEngine.startAudio(true);
        setIsAudioRunning(true);
        setIsSimulated(true);
      }
    };
    startMic();

    return () => {
      audioEngine.stopAudio();
      soundEffects.stopBeep();
    };
  }, []);

  // Sync sound & TTS state
  useEffect(() => {
    soundEffects.setMuted(!soundEnabled);
  }, [soundEnabled]);

  useEffect(() => {
    haptics.setEnabled(vibeEnabled);
  }, [vibeEnabled]);

  useEffect(() => {
    ttsService.setEnabled(ttsEnabled);
  }, [ttsEnabled]);

  // Main evaluation handler
  const handleTelemetry = useCallback((t: SignalTelemetry) => {
    if (isFrozen) return;
    setTelemetry(t);

    const result = fusionEngineRef.current.evaluate(t);
    let effectiveState = result.state;

    // Latch Mode logic
    if (mode === 'latch') {
      if (effectiveState === 'CLOSED' || latchedClosed) {
        effectiveState = 'CLOSED';
        setLatchedClosed(true);
      }
    }

    setCurrentState(effectiveState);
    setConfidence(result.confidence);

    // State change handling
    if (result.changed) {
      const now = Date.now();
      if (result.state === 'CLOSED') {
        contactStartRef.current = now;
        setClosureCount(c => c + 1);

        // Feedback triggers
        if (mode === 'toggle-beep') {
          soundEffects.playShortChirp('pass');
        } else {
          soundEffects.startBeep();
        }
        haptics.triggerClosure();

        if (screenFlashEnabled) {
          setScreenFlashActive(true);
          setTimeout(() => setScreenFlashActive(false), 120);
        }

        if (ttsEnabled) {
          ttsService.speak('Closed');
        }

        // Add log
        setLogs(prev => [
          ...prev.slice(-199),
          {
            id: now.toString(),
            timestamp: now,
            state: 'CLOSED',
            confidence: result.confidence,
            mode
          }
        ]);
      } else if (result.state === 'OPEN') {
        let dur = 0;
        if (contactStartRef.current) {
          dur = now - contactStartRef.current;
          setTotalClosedMs(ms => ms + dur);
          contactStartRef.current = null;
        }

        soundEffects.stopBeep();
        haptics.triggerOpen();

        if (ttsEnabled) {
          ttsService.speak('Open');
        }

        // Add log
        setLogs(prev => [
          ...prev.slice(-199),
          {
            id: now.toString(),
            timestamp: now,
            state: 'OPEN',
            confidence: result.confidence,
            durationMs: dur,
            mode
          }
        ]);
      }
    }
  }, [isFrozen, mode, latchedClosed, screenFlashEnabled, ttsEnabled]);

  useEffect(() => {
    const unsub = audioEngine.onTelemetry(handleTelemetry);
    return () => unsub();
  }, [handleTelemetry]);

  // Save new profile
  const handleSaveProfile = (p: CalibrationProfile) => {
    setActiveProfile(p);
    fusionEngineRef.current.setProfile(p);
  };

  // Quick 2-tap recalibrate
  const handleQuickRecalibrate = () => {
    // Fast baseline reset using live values
    const newProfile: CalibrationProfile = {
      ...activeProfile,
      openRms: telemetry.rms,
      openDc: telemetry.dcOffset,
      openHum: telemetry.humIndex
    };
    handleSaveProfile(newProfile);
    soundEffects.playShortChirp('click');
    haptics.triggerPass();
  };

  // Reset counters
  const handleResetMetrics = () => {
    setClosureCount(0);
    setTotalClosedMs(0);
    setLatchedClosed(false);
    fusionEngineRef.current.resetState();
    soundEffects.stopBeep();
  };

  // Simulated toggle
  const toggleSimulationTouch = () => {
    const next = !simulatedClosed;
    setSimulatedClosed(next);
    audioEngine.setSimulatedClosed(next);
  };

  // UI Theme colors
  const stateColor = currentState === 'CLOSED'
    ? 'text-emerald-400'
    : currentState === 'OPEN'
    ? 'text-rose-500'
    : 'text-amber-400';

  const stateBorderColor = currentState === 'CLOSED'
    ? 'border-emerald-500 shadow-emerald-500/30'
    : currentState === 'OPEN'
    ? 'border-rose-600 shadow-rose-600/20'
    : 'border-amber-500 shadow-amber-500/20';

  const stateBgGradient = currentState === 'CLOSED'
    ? 'from-emerald-950/60 to-slate-900'
    : currentState === 'OPEN'
    ? 'from-rose-950/40 to-slate-900'
    : 'from-amber-950/40 to-slate-900';

  return (
    <div
      className={`min-h-screen bg-slate-950 text-slate-100 flex flex-col transition-colors duration-100 ${
        screenFlashActive ? 'bg-emerald-800' : 'bg-slate-950'
      }`}
    >
      {/* Top Professional App Bar */}
      <header className="border-b border-slate-800/80 bg-slate-900/90 backdrop-blur px-4 py-3 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <Zap className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-black tracking-wider text-slate-100 uppercase">
                VoltJack
              </h1>
              <span className="text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                PROBE V1.0
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              3.5mm TRRS Hardware Continuity Tester & Studio
            </p>
          </div>
        </div>

        {/* Top actions */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          <button
            onClick={() => setIsSafetyOpen(true)}
            className="p-2 rounded-lg bg-amber-950/50 hover:bg-amber-900/80 text-amber-400 border border-amber-800/60 transition"
            title="Safety Guidelines & Schematic"
            aria-label="Safety instructions"
          >
            <Shield className="w-4 h-4" />
          </button>

          <button
            onClick={() => setIsAndroidModalOpen(true)}
            className="py-1.5 px-3 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs uppercase tracking-wide flex items-center gap-1.5 transition shadow-lg shadow-emerald-500/20"
          >
            <Smartphone className="w-4 h-4" />
            <span className="hidden sm:inline">Android APK</span>
          </button>
        </div>
      </header>

      {/* Hardware Status Strip */}
      <div className="px-4 py-2 bg-slate-900/40 border-b border-slate-800/50 flex flex-wrap items-center justify-between text-xs gap-2">
        <div className="flex items-center gap-2.5">
          <span
            className={`flex items-center gap-1.5 font-bold px-2.5 py-1 rounded-full ${
              telemetry.headsetPlugged
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
            }`}
          >
            <Headphones className="w-3.5 h-3.5" />
            {telemetry.headsetPlugged ? '3.5mm JACK DETECTED' : '3.5mm JACK OPEN / UNPLUGGED'}
          </span>

          <span className="text-slate-400 hidden md:inline truncate max-w-xs">
            In: <strong className="text-slate-300">{telemetry.inputDeviceName}</strong>
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Simulation mode switch if mic not available */}
          {isSimulated && (
            <button
              onClick={toggleSimulationTouch}
              className={`py-1 px-2.5 rounded-lg text-xs font-bold uppercase transition flex items-center gap-1 ${
                simulatedClosed
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Simulate Probe: {simulatedClosed ? 'TOUCHING' : 'APART'}
            </button>
          )}

          <button
            onClick={handleQuickRecalibrate}
            className="py-1 px-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs uppercase tracking-wider transition"
            title="Zero out current open probe baseline"
          >
            Quick Zero
          </button>
        </div>
      </div>

      {/* Main Container */}
      <main className="flex-1 max-w-4xl w-full mx-auto p-3 sm:p-5 flex flex-col gap-4">
        {/* Massive Multimeter Display Box */}
        <div
          className={`flex-1 min-h-[260px] sm:min-h-[340px] rounded-3xl border-4 bg-gradient-to-b ${stateBgGradient} ${stateBorderColor} shadow-2xl p-6 flex flex-col justify-between relative overflow-hidden transition-all duration-150`}
        >
          {/* Top readouts inside display */}
          <div className="flex items-center justify-between text-xs font-mono font-bold tracking-wider">
            <div className="flex items-center gap-2">
              <span className="bg-slate-950/80 px-2.5 py-1 rounded-md text-slate-300 border border-slate-800">
                MODE: {mode.toUpperCase()}
              </span>
              {isFrozen && (
                <span className="bg-cyan-500 text-slate-950 px-2 py-0.5 rounded font-black uppercase animate-pulse">
                  FROZEN / HOLD
                </span>
              )}
            </div>

            <div className="bg-slate-950/80 px-3 py-1 rounded-md text-slate-200 border border-slate-800">
              CONFIDENCE: <span className="text-emerald-400 font-black">{confidence}%</span>
            </div>
          </div>

          {/* Central State Indicator */}
          <div className="my-auto py-4 text-center">
            <div className={`text-6xl sm:text-8xl font-black font-mono tracking-widest uppercase ${stateColor} drop-shadow-md select-none`}>
              {currentState}
            </div>
            <div className="mt-2 text-xs sm:text-sm font-bold uppercase tracking-wider text-slate-400">
              {currentState === 'CLOSED' && 'Continuity Verified (< 2.2kΩ Path)'}
              {currentState === 'OPEN' && 'Infinite Impedance (Open Circuit)'}
              {currentState === 'UNKNOWN' && 'Sampling Audio & Headset Bus...'}
            </div>
          </div>

          {/* Bottom Oscilloscope / Signal Bars */}
          <div className="space-y-3 bg-slate-950/70 p-4 rounded-2xl border border-slate-800/80">
            {/* Confidence Bar */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] font-mono text-slate-400">
                <span>Signal Decision Margin</span>
                <span>{confidence}%</span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-75 ${
                    currentState === 'CLOSED' ? 'bg-emerald-500' : 'bg-rose-500'
                  }`}
                  style={{ width: `${confidence}%` }}
                />
              </div>
            </div>

            {/* Live sensor indicators */}
            <div className="grid grid-cols-4 gap-2 text-center text-xs font-mono pt-1">
              <div className="p-1.5 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase block font-sans">Mic RMS</span>
                <span className="text-cyan-400 font-bold">{(telemetry.rms * 100).toFixed(0)}%</span>
              </div>
              <div className="p-1.5 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase block font-sans">Peak</span>
                <span className="text-amber-400 font-bold">{(telemetry.peak * 100).toFixed(0)}%</span>
              </div>
              <div className="p-1.5 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase block font-sans">DC Drift</span>
                <span className="text-emerald-400 font-bold">{telemetry.dcOffset.toFixed(2)}</span>
              </div>
              <div className="p-1.5 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase block font-sans">Hum</span>
                <span className="text-purple-400 font-bold">{(telemetry.humIndex * 100).toFixed(0)}%</span>
              </div>
            </div>
          </div>
        </div>

        {/* Counter & Timer Metric Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-slate-400 font-bold uppercase block">Closure Count</span>
              <span className="text-xl font-mono font-black text-slate-100">{closureCount}</span>
            </div>
            <button
              onClick={handleResetMetrics}
              className="p-1.5 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition"
              title="Reset counter"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>

          <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800">
            <span className="text-[10px] text-slate-400 font-bold uppercase block">Total Closed Time</span>
            <span className="text-xl font-mono font-black text-cyan-400">
              {(totalClosedMs / 1000).toFixed(2)}s
            </span>
          </div>

          <button
            onClick={() => setIsFrozen(!isFrozen)}
            className={`p-3 rounded-2xl border flex items-center justify-between font-bold text-xs uppercase tracking-wider transition ${
              isFrozen
                ? 'bg-cyan-500 text-slate-950 border-cyan-400 shadow-lg shadow-cyan-500/20'
                : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
            }`}
          >
            <span>{isFrozen ? 'Unfreeze' : 'Hold Display'}</span>
            {isFrozen ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
          </button>

          <button
            onClick={() => setIsCalibrationOpen(true)}
            className="p-3 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-200 flex items-center justify-between font-bold text-xs uppercase tracking-wider transition"
          >
            <span>Calibrate</span>
            <Sliders className="w-4 h-4 text-blue-400" />
          </button>
        </div>

        {/* Feedback Option Toggles */}
        <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Feedback Outputs
            </span>
            <span className="text-[10px] text-slate-500 font-mono">
              Speaker Out: {telemetry.outputDeviceName}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className={`p-2.5 rounded-xl border flex items-center gap-2 text-xs font-bold transition ${
                soundEnabled
                  ? 'bg-emerald-600/20 text-emerald-400 border-emerald-500/40'
                  : 'bg-slate-800/40 text-slate-500 border-slate-700/40'
              }`}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              <span>Buzzer Tone</span>
            </button>

            <button
              onClick={() => setVibeEnabled(!vibeEnabled)}
              className={`p-2.5 rounded-xl border flex items-center gap-2 text-xs font-bold transition ${
                vibeEnabled
                  ? 'bg-cyan-600/20 text-cyan-400 border-cyan-500/40'
                  : 'bg-slate-800/40 text-slate-500 border-slate-700/40'
              }`}
            >
              <Vibrate className="w-4 h-4" />
              <span>Vibration</span>
            </button>

            <button
              onClick={() => setScreenFlashEnabled(!screenFlashEnabled)}
              className={`p-2.5 rounded-xl border flex items-center gap-2 text-xs font-bold transition ${
                screenFlashEnabled
                  ? 'bg-amber-600/20 text-amber-400 border-amber-500/40'
                  : 'bg-slate-800/40 text-slate-500 border-slate-700/40'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>Screen Flash</span>
            </button>

            <button
              onClick={() => setTtsEnabled(!ttsEnabled)}
              className={`p-2.5 rounded-xl border flex items-center gap-2 text-xs font-bold transition ${
                ttsEnabled
                  ? 'bg-purple-600/20 text-purple-400 border-purple-500/40'
                  : 'bg-slate-800/40 text-slate-500 border-slate-700/40'
              }`}
            >
              <Activity className="w-4 h-4" />
              <span>Spoken Voice</span>
            </button>
          </div>
        </div>

        {/* Operating Modes Switcher */}
        <div className="flex flex-wrap items-center gap-2 p-2 bg-slate-900 rounded-2xl border border-slate-800">
          <span className="text-[10px] font-bold uppercase text-slate-400 px-3">Mode:</span>
          {(['live', 'latch', 'toggle-beep', 'counter'] as TesterMode[]).map(m => (
            <button
              key={m}
              onClick={() => {
                setMode(m);
                if (m !== 'latch') setLatchedClosed(false);
              }}
              className={`py-1.5 px-3 rounded-xl text-xs font-bold uppercase tracking-wider transition ${
                mode === m
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                  : 'bg-slate-800/60 text-slate-400 hover:text-slate-200'
              }`}
            >
              {m}
            </button>
          ))}

          <button
            onClick={() => setIsPairTestOpen(true)}
            className="py-1.5 px-3 rounded-xl text-xs font-bold uppercase tracking-wider bg-indigo-950/60 text-indigo-400 border border-indigo-800/60 hover:bg-indigo-900 transition flex items-center gap-1.5 ml-auto"
          >
            <Layers className="w-3.5 h-3.5" /> Pair Sequencer
          </button>
        </div>

        {/* Bottom Utility Bar */}
        <div className="flex items-center justify-between text-xs py-2 text-slate-400">
          <button
            onClick={() => setIsDiagnosticsOpen(true)}
            className="hover:text-slate-200 flex items-center gap-1.5 font-bold uppercase tracking-wider"
          >
            <Activity className="w-3.5 h-3.5 text-cyan-400" /> Diagnostics & Raw Signals
          </button>

          <button
            onClick={() => setIsLogsOpen(true)}
            className="hover:text-slate-200 flex items-center gap-1.5 font-bold uppercase tracking-wider"
          >
            <History className="w-3.5 h-3.5 text-purple-400" /> Test History ({logs.length})
          </button>
        </div>
      </main>

      {/* Modals */}
      <CalibrationModal
        isOpen={isCalibrationOpen}
        onClose={() => setIsCalibrationOpen(false)}
        telemetry={telemetry}
        activeProfile={activeProfile}
        onSaveProfile={handleSaveProfile}
      />

      <DiagnosticsModal
        isOpen={isDiagnosticsOpen}
        onClose={() => setIsDiagnosticsOpen(false)}
        telemetry={telemetry}
        profile={activeProfile}
        currentState={currentState}
        confidence={confidence}
        closureCount={closureCount}
        elapsedClosedMs={totalClosedMs}
      />

      <LogViewModal
        isOpen={isLogsOpen}
        onClose={() => setIsLogsOpen(false)}
        logs={logs}
        onClearLogs={() => setLogs([])}
      />

      <PairTestModal
        isOpen={isPairTestOpen}
        onClose={() => setIsPairTestOpen(false)}
        currentState={currentState}
        confidence={confidence}
      />

      <SafetyModal
        isOpen={isSafetyOpen}
        onClose={() => setIsSafetyOpen(false)}
      />

      <AndroidProjectModal
        isOpen={isAndroidModalOpen}
        onClose={() => setIsAndroidModalOpen(false)}
      />
    </div>
  );
};
