import React, { useState, useEffect } from 'react';
import { Activity, Copy, Check, X, Cpu, Volume2, Mic, Smartphone } from 'lucide-react';
import { SignalTelemetry, CalibrationProfile, ContinuityState } from '../types';
import { audioEngine } from '../services/audioEngine';
import { soundEffects } from '../services/soundEffects';
import { haptics } from '../services/haptics';

interface DiagnosticsModalProps {
  isOpen: boolean;
  onClose: () => void;
  telemetry: SignalTelemetry;
  profile: CalibrationProfile;
  currentState: ContinuityState;
  confidence: number;
  closureCount: number;
  elapsedClosedMs: number;
}

export const DiagnosticsModal: React.FC<DiagnosticsModalProps> = ({
  isOpen,
  onClose,
  telemetry,
  profile,
  currentState,
  confidence,
  closureCount,
  elapsedClosedMs
}) => {
  const [copied, setCopied] = useState(false);
  const [deviceList, setDeviceList] = useState<MediaDeviceInfo[]>([]);
  const [audioCtxState, setAudioCtxState] = useState<string>('idle');
  const [sampleRate, setSampleRate] = useState<number>(44100);

  useEffect(() => {
    if (isOpen) {
      audioEngine.inspectDevices().then(setDeviceList);
      const ctx = audioEngine.getAudioContext();
      if (ctx) {
        setAudioCtxState(ctx.state);
        setSampleRate(ctx.sampleRate);
      }
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const copyDiagnosticReport = () => {
    const report = `
=== VOLTJACK 3.5mm HARDWARE DIAGNOSTIC REPORT ===
Timestamp: ${new Date().toISOString()}
User Agent: ${navigator.userAgent}
Screen: ${window.innerWidth}x${window.innerHeight}

--- AUDIO CONTEXT & SYSTEM ---
Context State: ${audioCtxState}
Sample Rate: ${sampleRate} Hz
Input Running: ${audioEngine.getIsRunning()}
Is Simulated: ${audioEngine.isSimulatedMode()}
Audio Permission: ${audioEngine.getHasAudioPermission()}

--- ACTIVE HARDWARE SIGNALS ---
Continuity State: ${currentState}
Confidence: ${confidence}%
Headset Mode Active: ${telemetry.headsetPlugged ? 'YES (Detected)' : 'NO (Unplugged/Open)'}
Mic RMS Amplitude: ${(telemetry.rms * 100).toFixed(1)}% (Raw: ${telemetry.rms.toFixed(4)})
Mic Peak Amplitude: ${(telemetry.peak * 100).toFixed(1)}% (Raw: ${telemetry.peak.toFixed(4)})
DC Offset Shift: ${telemetry.dcOffset.toFixed(4)}
50Hz/60Hz Hum Index: ${(telemetry.humIndex * 100).toFixed(1)}%
Active Audio Input: ${telemetry.inputDeviceName}
Active Audio Output: ${telemetry.outputDeviceName}

--- CALIBRATION THRESHOLDS ---
Profile Name: ${profile.name}
Open Baseline RMS: ${profile.openRms.toFixed(3)}
Closed Baseline RMS: ${profile.closedRms.toFixed(3)}
Open DC: ${profile.openDc.toFixed(3)} | Closed DC: ${profile.closedDc.toFixed(3)}
Open Hum: ${profile.openHum.toFixed(3)} | Closed Hum: ${profile.closedHum.toFixed(3)}
Weights: Plug=${profile.weightHeadsetPlug}, RMS=${profile.weightRms}, DC=${profile.weightDc}, Hum=${profile.weightHum}
Debounce: ${profile.debounceMs}ms | Min Hold: ${profile.minHoldMs}ms | Hysteresis: ${profile.hysteresisPercent}%

--- COUNTERS & SESSION ---
Total Closures Detected: ${closureCount}
Total Closed Time: ${(elapsedClosedMs / 1000).toFixed(2)}s

--- DETECTED MEDIA DEVICES ---
${deviceList.map((d, i) => `${i + 1}. [${d.kind}] ${d.label || 'Unknown'} (id: ${d.deviceId.slice(0, 8)}...)`).join('\n')}
=================================================
`.trim();

    navigator.clipboard.writeText(report);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-cyan-500/30 rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl text-slate-100 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-950/80">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-cyan-500/20 text-cyan-400">
              <Activity className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-black tracking-wide text-cyan-300 uppercase">
                Hardware & Audio Diagnostics
              </h2>
              <p className="text-xs text-slate-400">Live hardware telemetry and device status</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-6 text-sm">
          {/* Live Telemetry Grid */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
              <Cpu className="w-4 h-4 text-cyan-400" /> Live Signal Sensor Readouts
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700">
                <span className="text-[10px] text-slate-400 font-bold uppercase">RMS Amplitude</span>
                <p className="text-lg font-mono font-bold text-cyan-400">{(telemetry.rms * 100).toFixed(1)}%</p>
                <div className="w-full bg-slate-700 h-1.5 rounded-full mt-1.5 overflow-hidden">
                  <div className="bg-cyan-500 h-full transition-all duration-75" style={{ width: `${Math.min(100, telemetry.rms * 100)}%` }} />
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700">
                <span className="text-[10px] text-slate-400 font-bold uppercase">Peak Value</span>
                <p className="text-lg font-mono font-bold text-amber-400">{(telemetry.peak * 100).toFixed(1)}%</p>
                <div className="w-full bg-slate-700 h-1.5 rounded-full mt-1.5 overflow-hidden">
                  <div className="bg-amber-500 h-full transition-all duration-75" style={{ width: `${Math.min(100, telemetry.peak * 100)}%` }} />
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700">
                <span className="text-[10px] text-slate-400 font-bold uppercase">DC Offset Shift</span>
                <p className="text-lg font-mono font-bold text-emerald-400">{telemetry.dcOffset.toFixed(3)}</p>
                <span className="text-[10px] text-slate-500">Zero-bias drift</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700">
                <span className="text-[10px] text-slate-400 font-bold uppercase">50/60Hz Hum</span>
                <p className="text-lg font-mono font-bold text-purple-400">{(telemetry.humIndex * 100).toFixed(1)}%</p>
                <div className="w-full bg-slate-700 h-1.5 rounded-full mt-1.5 overflow-hidden">
                  <div className="bg-purple-500 h-full transition-all duration-75" style={{ width: `${Math.min(100, telemetry.humIndex * 100)}%` }} />
                </div>
              </div>
            </div>
          </div>

          {/* Audio Routing & Headset State */}
          <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-700/80 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-emerald-400" /> Audio Routing & Jack State
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="flex items-center gap-2.5 p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
                <Mic className="w-4 h-4 text-emerald-400 shrink-0" />
                <div>
                  <p className="text-slate-400 text-[10px] uppercase font-bold">Input Device</p>
                  <p className="font-semibold text-slate-200 truncate">{telemetry.inputDeviceName}</p>
                </div>
              </div>

              <div className="flex items-center gap-2.5 p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
                <Volume2 className="w-4 h-4 text-cyan-400 shrink-0" />
                <div>
                  <p className="text-slate-400 text-[10px] uppercase font-bold">Output Route</p>
                  <p className="font-semibold text-slate-200 truncate">{telemetry.outputDeviceName}</p>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-800 text-slate-400">
              <span>Sample Rate: <strong className="text-slate-200">{sampleRate} Hz</strong></span>
              <span>Audio State: <strong className="text-emerald-400">{audioCtxState}</strong></span>
              <span>Headset Plug: <strong className={telemetry.headsetPlugged ? "text-emerald-400" : "text-amber-400"}>{telemetry.headsetPlugged ? "DETECTED" : "OPEN"}</strong></span>
            </div>
          </div>

          {/* Quick Hardware Test Buttons */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Self-Test Hardware Outputs
            </h3>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => soundEffects.playShortChirp('pass')}
                className="py-2 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 flex items-center gap-1.5 transition"
              >
                <Volume2 className="w-3.5 h-3.5 text-emerald-400" /> Test Speaker Chirp
              </button>
              <button
                onClick={() => haptics.triggerClosure()}
                className="py-2 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 flex items-center gap-1.5 transition"
              >
                <Activity className="w-3.5 h-3.5 text-cyan-400" /> Test Vibration
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
          <p className="text-xs text-slate-400">Attach report when troubleshooting probe issues</p>
          <button
            onClick={copyDiagnosticReport}
            className="py-2.5 px-4 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs uppercase tracking-wider flex items-center gap-2 transition shadow-lg shadow-cyan-600/20"
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            {copied ? 'Copied to Clipboard!' : 'Copy Diagnostic Report'}
          </button>
        </div>
      </div>
    </div>
  );
};
