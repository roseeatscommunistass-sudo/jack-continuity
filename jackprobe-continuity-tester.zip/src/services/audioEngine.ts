import { SignalTelemetry } from '../types';

export type TelemetryCallback = (telemetry: SignalTelemetry) => void;
export type DeviceChangeCallback = (devices: MediaDeviceInfo[]) => void;

class AudioEngineService {
  private audioCtx: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private analyserNode: AnalyserNode | null = null;
  private animFrameId: number | null = null;
  
  private telemetryCallbacks: Set<TelemetryCallback> = new Set();
  private deviceCallbacks: Set<DeviceChangeCallback> = new Set();

  private isRunning: boolean = false;
  private isSimulated: boolean = false;
  private simulatedClosed: boolean = false;
  private hasAudioPermission: boolean = false;
  private errorMessage: string | null = null;

  // Cached hardware state
  private inputDeviceName: string = 'Detecting...';
  private outputDeviceName: string = 'Default Speaker';
  private headsetPlugged: boolean = false;
  private lastSampleRate: number = 48000;

  constructor() {
    this.setupDeviceChangeListener();
    this.setupHardwareKeyListeners();
  }

  private setupDeviceChangeListener() {
    if (typeof navigator !== 'undefined' && navigator.mediaDevices?.addEventListener) {
      navigator.mediaDevices.addEventListener('devicechange', async () => {
        await this.inspectDevices();
      });
    }
  }

  private setupHardwareKeyListeners() {
    if (typeof window !== 'undefined') {
      window.addEventListener('keydown', (e) => {
        // Headset hook / media key detection
        if (e.code === 'HeadsetHook' || e.code === 'MediaPlayPause' || e.key === 'MediaPlayPause') {
          this.triggerHeadsetHookEvent();
        }
      });
    }
  }

  private triggerHeadsetHookEvent() {
    // When 2.2k probe touches, some Android codecs detect it as Headset Button Press
    this.headsetPlugged = true;
  }

  public async inspectDevices(): Promise<MediaDeviceInfo[]> {
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.enumerateDevices) {
      return [];
    }
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      
      const inputs = devices.filter(d => d.kind === 'audioinput');
      const outputs = devices.filter(d => d.kind === 'audiooutput');

      const headsetInput = inputs.find(d => 
        d.label.toLowerCase().includes('headset') || 
        d.label.toLowerCase().includes('wired') ||
        d.label.toLowerCase().includes('3.5') ||
        d.label.toLowerCase().includes('external')
      );

      const headsetOutput = outputs.find(d => 
        d.label.toLowerCase().includes('headphone') || 
        d.label.toLowerCase().includes('headset') ||
        d.label.toLowerCase().includes('wired')
      );

      this.headsetPlugged = !!(headsetInput || headsetOutput);

      if (headsetInput) {
        this.inputDeviceName = headsetInput.label || 'Wired Headset Mic';
      } else if (inputs.length > 0) {
        this.inputDeviceName = inputs[0].label || 'Default Audio Input';
      } else {
        this.inputDeviceName = 'No Input Device';
      }

      if (headsetOutput) {
        this.outputDeviceName = headsetOutput.label || 'Wired Headphone';
      } else if (outputs.length > 0) {
        this.outputDeviceName = outputs[0].label || 'Internal Speaker';
      } else {
        this.outputDeviceName = 'Standard Speaker';
      }

      this.deviceCallbacks.forEach(cb => cb(devices));
      return devices;
    } catch {
      return [];
    }
  }

  public async startAudio(useSimulation: boolean = false): Promise<boolean> {
    this.errorMessage = null;
    this.isSimulated = useSimulation;

    if (useSimulation) {
      this.isRunning = true;
      this.startSimulatedLoop();
      return true;
    }

    try {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.audioCtx = new AudioContextClass({ latencyHint: 'interactive' });
      if (this.audioCtx.state === 'suspended') {
        await this.audioCtx.resume();
      }
      this.lastSampleRate = this.audioCtx.sampleRate;

      // Request raw, unconstrained audio with no digital processing
      const constraints: MediaStreamConstraints = {
        audio: {
          echoCancellation: false,
          noiseSuppression: false,
          autoGainControl: false,
          channelCount: 1,
        },
        video: false
      };

      this.mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
      this.hasAudioPermission = true;

      await this.inspectDevices();

      this.sourceNode = this.audioCtx.createMediaStreamSource(this.mediaStream);
      this.analyserNode = this.audioCtx.createAnalyser();
      this.analyserNode.fftSize = 1024;
      this.analyserNode.smoothingTimeConstant = 0.2; // Quick response

      this.sourceNode.connect(this.analyserNode);

      this.isRunning = true;
      this.startAnalysisLoop();
      return true;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      this.errorMessage = `Microphone access error: ${msg}. You can test using the hardware simulation mode or verify browser permissions.`;
      console.warn('AudioEngine start error:', err);
      return false;
    }
  }

  public stopAudio() {
    this.isRunning = false;
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }

    if (this.sourceNode) {
      try { this.sourceNode.disconnect(); } catch {}
      this.sourceNode = null;
    }
    if (this.analyserNode) {
      try { this.analyserNode.disconnect(); } catch {}
      this.analyserNode = null;
    }
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach(track => track.stop());
      this.mediaStream = null;
    }
    if (this.audioCtx) {
      try { this.audioCtx.close(); } catch {}
      this.audioCtx = null;
    }
  }

  private startAnalysisLoop() {
    if (!this.analyserNode) return;
    const timeBuffer = new Float32Array(this.analyserNode.fftSize);
    const freqBuffer = new Uint8Array(this.analyserNode.frequencyBinCount);

    const tick = () => {
      if (!this.isRunning || !this.analyserNode) return;

      this.analyserNode.getFloatTimeDomainData(timeBuffer);
      this.analyserNode.getByteFrequencyData(freqBuffer);

      // 1. RMS & Peak Calculation
      let sumSquares = 0;
      let peak = 0;
      let sumDC = 0;

      for (let i = 0; i < timeBuffer.length; i++) {
        const val = timeBuffer[i];
        sumSquares += val * val;
        sumDC += val;
        const absVal = Math.abs(val);
        if (absVal > peak) peak = absVal;
      }

      const rms = Math.sqrt(sumSquares / timeBuffer.length);
      const dcOffset = sumDC / timeBuffer.length;

      // 2. Hum Index: Check 50Hz/60Hz frequency bin vs total frequency magnitude
      // Frequency resolution = sampleRate / fftSize (e.g. 48000 / 1024 ≈ 46.8 Hz per bin)
      // Bin 1 ≈ 47Hz, Bin 2 ≈ 94Hz (50/60Hz falls between bin 1 and 2)
      const humMagnitude = (freqBuffer[1] + freqBuffer[2]) / 2 / 255;
      let totalSpectralSum = 0;
      for (let i = 0; i < freqBuffer.length; i++) {
        totalSpectralSum += freqBuffer[i];
      }
      const avgSpectral = totalSpectralSum / (freqBuffer.length * 255);
      const humRatio = avgSpectral > 0.001 ? Math.min(1.0, humMagnitude / (avgSpectral * 2.5)) : humMagnitude;

      const telemetry: SignalTelemetry = {
        rms: Math.min(1.0, rms * 4.0), // Scaled for usability
        peak: Math.min(1.0, peak * 2.5),
        dcOffset,
        humIndex: humRatio,
        headsetPlugged: this.headsetPlugged,
        inputDeviceName: this.inputDeviceName,
        outputDeviceName: this.outputDeviceName,
        timestamp: Date.now()
      };

      this.telemetryCallbacks.forEach(cb => cb(telemetry));
      this.animFrameId = requestAnimationFrame(tick);
    };

    this.animFrameId = requestAnimationFrame(tick);
  }

  private startSimulatedLoop() {
    let phase = 0;
    const tick = () => {
      if (!this.isRunning) return;
      phase += 0.05;

      const closed = this.simulatedClosed;
      // Closed: clean low noise floor, strong ground tie, low hum, headset flag active
      // Open: higher antenna floating noise, noticeable 50/60Hz hum, headset flag off or idle
      const noise = (Math.sin(phase * 3.1) * 0.02) + (Math.random() * 0.01);
      
      const rms = closed ? 0.03 + noise : 0.45 + noise * 4;
      const peak = closed ? 0.06 : 0.65;
      const dcOffset = closed ? -0.15 : 0.02;
      const humIndex = closed ? 0.05 : 0.72;

      const telemetry: SignalTelemetry = {
        rms: Math.max(0, Math.min(1.0, rms)),
        peak: Math.max(0, Math.min(1.0, peak)),
        dcOffset,
        humIndex: Math.max(0, Math.min(1.0, humIndex)),
        headsetPlugged: closed,
        inputDeviceName: closed ? 'Wired 3.5mm Headset Probe (Sim)' : 'Phone Internal Mic (Sim)',
        outputDeviceName: 'Speaker Out',
        timestamp: Date.now()
      };

      this.telemetryCallbacks.forEach(cb => cb(telemetry));
      this.animFrameId = requestAnimationFrame(tick);
    };
    this.animFrameId = requestAnimationFrame(tick);
  }

  public setSimulatedClosed(closed: boolean) {
    this.simulatedClosed = closed;
  }

  public isSimulatedMode(): boolean {
    return this.isSimulated;
  }

  public getIsRunning(): boolean {
    return this.isRunning;
  }

  public getHasAudioPermission(): boolean {
    return this.hasAudioPermission;
  }

  public getErrorMessage(): string | null {
    return this.errorMessage;
  }

  public getAudioContext(): AudioContext | null {
    return this.audioCtx;
  }

  public getSampleRate(): number {
    return this.audioCtx ? this.audioCtx.sampleRate : this.lastSampleRate;
  }

  public onTelemetry(cb: TelemetryCallback) {
    this.telemetryCallbacks.add(cb);
    return () => { this.telemetryCallbacks.delete(cb); };
  }

  public onDeviceChange(cb: DeviceChangeCallback) {
    this.deviceCallbacks.add(cb);
    return () => { this.deviceCallbacks.delete(cb); };
  }
}

export const audioEngine = new AudioEngineService();
