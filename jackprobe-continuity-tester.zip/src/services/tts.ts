/**
 * Text-to-Speech Voice Alert Service
 */

class TtsService {
  private enabled: boolean = false;
  private lastSpokenText: string = '';
  private lastSpokenTime: number = 0;

  public setEnabled(enable: boolean) {
    this.enabled = enable;
  }

  public isEnabled(): boolean {
    return this.enabled;
  }

  public speak(text: string, force: boolean = false) {
    if (!this.enabled || typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    
    // Throttle repeated phrases to prevent voice queue buildup
    const now = Date.now();
    if (!force && this.lastSpokenText === text && now - this.lastSpokenTime < 1500) {
      return;
    }

    try {
      window.speechSynthesis.cancel(); // Cancel any lingering utterance
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.2;
      utterance.pitch = 1.0;
      utterance.volume = 1.0;
      this.lastSpokenText = text;
      this.lastSpokenTime = now;
      window.speechSynthesis.speak(utterance);
    } catch {
      // Ignore TTS error
    }
  }
}

export const ttsService = new TtsService();
