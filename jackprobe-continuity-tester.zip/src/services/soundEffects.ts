/**
 * Audio Continuity Buzzer Generator
 * Generates low-latency, click-free continuity beeps using Web Audio API
 */

class SoundEffectsService {
  private audioCtx: AudioContext | null = null;
  private oscNode: OscillatorNode | null = null;
  private gainNode: GainNode | null = null;
  private isBeeping: boolean = false;
  private frequency: number = 960; // Standard multimeter beep frequency
  private volume: number = 0.8;
  private isMuted: boolean = false;

  private initContext() {
    if (!this.audioCtx) {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.audioCtx = new AudioContextClass();
    }
    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (muted && this.isBeeping) {
      this.stopBeep();
    }
  }

  public setFrequency(freq: number) {
    this.frequency = Math.max(200, Math.min(3000, freq));
    if (this.oscNode && this.audioCtx) {
      this.oscNode.frequency.setValueAtTime(this.frequency, this.audioCtx.currentTime);
    }
  }

  public setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.gainNode && this.audioCtx && this.isBeeping) {
      this.gainNode.gain.setValueAtTime(this.volume, this.audioCtx.currentTime);
    }
  }

  public startBeep() {
    if (this.isMuted || this.isBeeping) return;
    try {
      this.initContext();
      if (!this.audioCtx) return;

      const now = this.audioCtx.currentTime;
      this.oscNode = this.audioCtx.createOscillator();
      this.gainNode = this.audioCtx.createGain();

      this.oscNode.type = 'sine';
      this.oscNode.frequency.setValueAtTime(this.frequency, now);

      // Fast anti-click attack (5ms)
      this.gainNode.gain.setValueAtTime(0.0001, now);
      this.gainNode.gain.linearRampToValueAtTime(this.volume, now + 0.005);

      this.oscNode.connect(this.gainNode);
      this.gainNode.connect(this.audioCtx.destination);

      this.oscNode.start(now);
      this.isBeeping = true;
    } catch (e) {
      console.warn('Audio tone could not start:', e);
    }
  }

  public stopBeep() {
    if (!this.isBeeping || !this.audioCtx || !this.gainNode) return;
    try {
      const now = this.audioCtx.currentTime;
      // Fast anti-click release (8ms)
      this.gainNode.gain.setValueAtTime(this.gainNode.gain.value, now);
      this.gainNode.gain.linearRampToValueAtTime(0.0001, now + 0.008);
      
      const osc = this.oscNode;
      setTimeout(() => {
        try {
          osc?.stop();
          osc?.disconnect();
        } catch {
          // ignore
        }
      }, 15);
      
      this.oscNode = null;
      this.gainNode = null;
      this.isBeeping = false;
    } catch (e) {
      console.warn('Audio tone could not stop smoothly:', e);
      this.isBeeping = false;
    }
  }

  public playShortChirp(type: 'pass' | 'fail' | 'click') {
    if (this.isMuted) return;
    try {
      this.initContext();
      if (!this.audioCtx) return;
      const now = this.audioCtx.currentTime;
      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();
      
      const freq = type === 'pass' ? 1400 : type === 'fail' ? 320 : 800;
      const dur = type === 'pass' ? 0.12 : type === 'fail' ? 0.25 : 0.04;
      
      osc.type = type === 'fail' ? 'sawtooth' : 'sine';
      osc.frequency.setValueAtTime(freq, now);
      if (type === 'pass') {
        osc.frequency.exponentialRampToValueAtTime(1800, now + dur);
      }

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(this.volume * 0.7, now + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + dur);

      osc.connect(gain);
      gain.connect(this.audioCtx.destination);
      osc.start(now);
      osc.stop(now + dur + 0.02);
    } catch {
      // ignore
    }
  }
}

export const soundEffects = new SoundEffectsService();
