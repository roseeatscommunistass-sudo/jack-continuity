import { CalibrationProfile, ContinuityState, SignalTelemetry } from '../types';

export const DEFAULT_CALIBRATION_PROFILE: CalibrationProfile = {
  id: 'default-profile',
  name: 'Standard 2.2kΩ TRRS Probe',
  description: 'Factory calibrated for CTIA 3.5mm jack with 2.2k resistor and 5.1V clamp',
  createdAt: Date.now(),
  openRms: 0.35,
  closedRms: 0.05,
  openDc: 0.01,
  closedDc: -0.12,
  openHum: 0.65,
  closedHum: 0.08,
  weightHeadsetPlug: 0.45,
  weightRms: 0.25,
  weightDc: 0.15,
  weightHum: 0.15,
  debounceMs: 35,
  minHoldMs: 60,
  hysteresisPercent: 12,
  sensitivityPreset: 'normal'
};

export class FusionEngine {
  private profile: CalibrationProfile = { ...DEFAULT_CALIBRATION_PROFILE };
  private currentState: ContinuityState = 'UNKNOWN';
  private rawClosedScore: number = 0; // 0 to 1
  private confidence: number = 0; // 0 to 100%

  // Debounce and hold tracking
  private candidateState: ContinuityState = 'UNKNOWN';
  private candidateSince: number = 0;
  private lastStateChangeTime: number = 0;

  constructor(initialProfile?: CalibrationProfile) {
    if (initialProfile) {
      this.profile = { ...initialProfile };
    }
  }

  public setProfile(profile: CalibrationProfile) {
    this.profile = { ...profile };
  }

  public getProfile(): CalibrationProfile {
    return this.profile;
  }

  /**
   * Process a telemetry frame and produce fused state & confidence
   */
  public evaluate(telemetry: SignalTelemetry): {
    state: ContinuityState;
    confidence: number;
    closedScore: number;
    changed: boolean;
  } {
    const now = Date.now();
    const p = this.profile;

    // 1. Headset Plug Score (0.0 if not plugged/detected, 1.0 if detected)
    const plugScore = telemetry.headsetPlugged ? 1.0 : 0.0;

    // 2. RMS Score: when closed, RMS is typically lower (or quiet ground tie)
    // If openRms > closedRms (normal case): lower RMS means closer to closed
    let rmsScore = 0.5;
    const rmsSpan = Math.abs(p.openRms - p.closedRms);
    if (rmsSpan > 0.01) {
      if (p.openRms > p.closedRms) {
        // Closer to closedRms -> score 1.0, closer to openRms -> score 0.0
        rmsScore = Math.max(0, Math.min(1.0, (p.openRms - telemetry.rms) / rmsSpan));
      } else {
        rmsScore = Math.max(0, Math.min(1.0, (telemetry.rms - p.openRms) / rmsSpan));
      }
    }

    // 3. DC Offset Score
    let dcScore = 0.5;
    const dcSpan = Math.abs(p.openDc - p.closedDc);
    if (dcSpan > 0.01) {
      const distToOpen = Math.abs(telemetry.dcOffset - p.openDc);
      const distToClosed = Math.abs(telemetry.dcOffset - p.closedDc);
      dcScore = Math.max(0, Math.min(1.0, distToOpen / (distToOpen + distToClosed)));
    }

    // 4. Hum Score: when closed, hum is attenuated by the 2.2k resistor to ground
    let humScore = 0.5;
    const humSpan = Math.abs(p.openHum - p.closedHum);
    if (humSpan > 0.02) {
      if (p.openHum > p.closedHum) {
        humScore = Math.max(0, Math.min(1.0, (p.openHum - telemetry.humIndex) / humSpan));
      } else {
        humScore = Math.max(0, Math.min(1.0, (telemetry.humIndex - p.openHum) / humSpan));
      }
    }

    // Weighted fusion of signals
    const totalWeight = p.weightHeadsetPlug + p.weightRms + p.weightDc + p.weightHum;
    const normPlug = p.weightHeadsetPlug / totalWeight;
    const normRms = p.weightRms / totalWeight;
    const normDc = p.weightDc / totalWeight;
    const normHum = p.weightHum / totalWeight;

    const closedScore = (plugScore * normPlug) + (rmsScore * normRms) + (dcScore * normDc) + (humScore * normHum);
    this.rawClosedScore = closedScore;

    // Apply Hysteresis:
    // Upper threshold to trip CLOSED: 0.50 + hysteresis
    // Lower threshold to trip OPEN: 0.50 - hysteresis
    const hystOffset = (p.hysteresisPercent / 100) / 2; // e.g. 0.06
    const upperThreshold = 0.50 + hystOffset;
    const lowerThreshold = 0.50 - hystOffset;

    let targetState: ContinuityState = 'UNKNOWN';
    if (closedScore >= upperThreshold) {
      targetState = 'CLOSED';
    } else if (closedScore <= lowerThreshold) {
      targetState = 'OPEN';
    } else {
      // In hysteresis band, keep current state or UNKNOWN if never set
      targetState = this.currentState !== 'UNKNOWN' ? this.currentState : 'UNKNOWN';
    }

    // Calculate confidence (0% to 100%)
    const distanceToThreshold = Math.abs(closedScore - 0.50);
    this.confidence = Math.round(Math.min(100, Math.max(10, distanceToThreshold * 200)));

    // Debounce & Minimum Hold
    if (targetState !== this.candidateState) {
      this.candidateState = targetState;
      this.candidateSince = now;
    }

    const candidateDuration = now - this.candidateSince;
    let changed = false;

    if (candidateDuration >= p.debounceMs && this.candidateState !== this.currentState) {
      const holdDuration = now - this.lastStateChangeTime;
      if (holdDuration >= p.minHoldMs || this.currentState === 'UNKNOWN') {
        this.currentState = this.candidateState;
        this.lastStateChangeTime = now;
        changed = true;
      }
    }

    return {
      state: this.currentState,
      confidence: this.confidence,
      closedScore: this.rawClosedScore,
      changed
    };
  }

  public getCurrentState(): ContinuityState {
    return this.currentState;
  }

  public getConfidence(): number {
    return this.confidence;
  }

  public resetState() {
    this.currentState = 'UNKNOWN';
    this.candidateState = 'UNKNOWN';
    this.candidateSince = 0;
    this.lastStateChangeTime = 0;
  }
}
