/**
 * Haptic Vibration Service
 * Triggers hardware vibration patterns for continuity transitions
 */

class HapticsService {
  private enabled: boolean = true;

  public setEnabled(enable: boolean) {
    this.enabled = enable;
  }

  public triggerClosure() {
    if (!this.enabled || typeof navigator === 'undefined' || !navigator.vibrate) return;
    try {
      // Crisp double-pulse for connection
      navigator.vibrate([40, 30, 60]);
    } catch {
      // Ignore vibration error on unsupported platforms
    }
  }

  public triggerOpen() {
    if (!this.enabled || typeof navigator === 'undefined' || !navigator.vibrate) return;
    try {
      // Single short pulse for disconnect
      navigator.vibrate(25);
    } catch {
      // Ignore
    }
  }

  public triggerPass() {
    if (!this.enabled || typeof navigator === 'undefined' || !navigator.vibrate) return;
    try {
      navigator.vibrate([30, 40, 80]);
    } catch {
      // Ignore
    }
  }

  public triggerFail() {
    if (!this.enabled || typeof navigator === 'undefined' || !navigator.vibrate) return;
    try {
      navigator.vibrate([150, 60, 150]);
    } catch {
      // Ignore
    }
  }
}

export const haptics = new HapticsService();
